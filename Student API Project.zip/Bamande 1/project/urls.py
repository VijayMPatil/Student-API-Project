
from django.contrib import admin
from django.urls import path
from myapp.views import *
    
urlpatterns = [
    path('admin/', admin.site.urls),
    path('student/add/',StudentAddAPI.as_view(),name='student_add'),
    path('student/update/',StudentUpdateAPI.as_view(),name='student_update'), 
    path('student/delete/',StudentDeleteView.as_view(),name='student_delete'),
    path('student/list/',StudentListAPI.as_view(),name='student_list'), 
]
